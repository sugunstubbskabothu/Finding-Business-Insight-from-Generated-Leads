create schema Leads_project;

select * from Leads_project.sampledata ;
select * from Leads_project.sampledata limit 20;

use Leads_project;

select count(*) from leads_project.sampledata ;

describe sampledata;

select `Prospect ID`,`Lead Number` from sampledata;  -- use this ( ` ) symbol for columns names which having space --

  -- checking for null values ----

select count(company) from sampledata;
select distinct(company) from sampledata;

select count(Company) from sampledata  -- NON NULL VALUES IN COMPANY COLUMN--
where company <> '' ;

select count(Company) from sampledata  -- NULL VALUES IN COMPANY COLUMN--
where company = '' ;

select COUNT(DISTINCT(`Lead Number`)) from sampledata  -- COUNT OF DISTINCT VALUES IN `LEAD NUMBER` COLUMN --
 ;
 
 select COUNT(`Lead Number`) from sampledata  -- NULL VALUES IN `Lead Number` COLUMN--
 WHERE `Lead Number` = '' ;
 
 select COUNT(`Lead Source`) from sampledata  -- NULL VALUES IN `Lead Source` COLUMN--
 WHERE `Lead Source` = '' ;
 
 select `what matters most to you in choosing a course` ,count(`what matters most to you in choosing a course`)
 from sampledata
 group by `what matters most to you in choosing a course`;
 
 select COUNT(`Prospect ID`) from sampledata  -- NULL VALUES IN `Prospect ID` COLUMN--
 WHERE `Prospect ID` = '' ;
 
 select COUNT(`Lead Origin`) from sampledata  -- NULL VALUES IN `Lead Origin` COLUMN--
 WHERE `Lead Origin` = '' ;
 
  select COUNT(`Do Not Email`) from sampledata  -- NULL VALUES IN `Do Not Email` COLUMN--
 WHERE `Do Not Email` = '' ;
 
select COUNT(`Do Not Call`) from sampledata  -- NULL VALUES IN `Do Not Call` COLUMN--
 WHERE `Do Not Call` = '' ;
 
 select COUNT(`TotalVisits`) from sampledata  -- NULL VALUES IN `TotalVisits` COLUMN--
 WHERE `TotalVisits` = '' ;

 select `TotalVisits` ,count(`TotalVisits`)
 from sampledata
 group by `TotalVisits`;
 
 select COUNT(`Total Time Spent on Website `) from sampledata  -- NULL VALUES IN `Total Time Spent on Website` COLUMN--
 WHERE `Total Time Spent on Website` = '' ;
 
 select `Total Time Spent on Website` ,count(`Total Time Spent on Website`)
 from sampledata
 group by `Total Time Spent on Website`;
 
 select COUNT(`Page Views Per Visit `) from sampledata  -- NULL VALUES IN `Page Views Per Visit` COLUMN--
 WHERE `Page Views Per Visit` = '' ;
 
 select `Page Views Per Visit` ,count(`Page Views Per Visit`)
 from sampledata
 group by `Page Views Per Visit`;
 
 select `Last Activity` ,count(`Last Activity`)
 from sampledata
 group by `Last Activity`;
 
 select `Country` ,count(`Country`)
 from sampledata
 group by `Country`;
 
 select `Specialization` ,count(`Specialization`)
 from sampledata
 group by `Specialization`;
 
 select COUNT(`Specialization `) from sampledata  -- NULL VALUES IN `Specialization` COLUMN--
 WHERE `Specialization` = '' ;
 
 select `How did you hear about X Education` ,count(`How did you hear about X Education`)
 from sampledata
 group by `How did you hear about X Education`;
 
 select `What is your current occupation` ,count(`What is your current occupation`)
 from sampledata
 group by `What is your current occupation`;
 
 select `Search` ,count(`Search`)
 from sampledata
 group by `Search`;
 
 select COUNT(`Search`) from sampledata  -- NULL VALUES IN `Search` COLUMN--
 WHERE `Search` = '' ;
 
 select `Magazine` ,count(`Magazine`)
 from sampledata
 group by `Magazine`;
 
select `Newspaper Article` ,count(`Newspaper Article`)
from sampledata
group by `Newspaper Article`;

select `X Education Forums` ,count(`X Education Forums`)
from sampledata
group by `X Education Forums`;

select `Newspaper` ,count(`Newspaper`)
from sampledata
group by `Newspaper`;

select `Digital Advertisement` ,count(`Digital Advertisement`)
from sampledata
group by `Digital Advertisement`;

select `Through Recommendations` ,count(`Through Recommendations`)
from sampledata
group by `Through Recommendations`;

select `Lead Quality` ,count(`Lead Quality`)
from sampledata
group by `Lead Quality`;

select `Update me on Supply Chain Content` ,count(`Update me on Supply Chain Content`)
from sampledata
group by `Update me on Supply Chain Content`;

select `Get updates on DM Content` ,count(`Get updates on DM Content`)
from sampledata
group by `Get updates on DM Content`;

select `Lead Profile` ,count(`Lead Profile`)
from sampledata
group by `Lead Profile`;

select `City` ,count(`City`)
from sampledata
group by `City`;

select `Asymmetrique Activity Index` ,count(`Asymmetrique Activity Index`)
from sampledata
group by `Asymmetrique Activity Index`;

select `Asymmetrique Profile Index` ,count(`Asymmetrique Profile Index`)
from sampledata
group by `Asymmetrique Profile Index`;

select `Asymmetrique Profile Score` ,count(`Asymmetrique Profile Score`)
from sampledata
group by `Asymmetrique Profile Score`;

select `I agree to pay the amount through cheque` ,count(`I agree to pay the amount through cheque`)
from sampledata
group by `I agree to pay the amount through cheque`;

select `A free copy of Mastering The Interview` ,count(`A free copy of Mastering The Interview`)
from sampledata
group by `A free copy of Mastering The Interview`;

select `Last Notable Activity` ,count(`Last Notable Activity`)
from sampledata
group by `Last Notable Activity`;

select `Converted` ,count(`Converted`)
from sampledata
group by `Converted`;



create table lead_data
select `Prospect ID`,`Lead Number`,`Lead Origin`,`Lead Source`,`Do Not Email`,`Do Not Call`,`TotalVisits`,`Total Time Spent on Website`,
`Page Views Per Visit`,`Last Activity`,`Country`,`Specialization`,`How did you hear about X Education`,`What is your current occupation`,
`what matters most to you in choosing a course`,`Search`,`Magazine`,`Newspaper Article`,`X Education Forums`,`Newspaper`,`Digital Advertisement`,
`Through Recommendations`,`Lead Quality`,`Update me on Supply Chain Content`,`Get updates on DM Content`,`Lead Profile`,`City`,`Asymmetrique Activity Index`,
`Asymmetrique Profile Index`,`Asymmetrique Profile Score`,`I agree to pay the amount through cheque`,`A free copy of Mastering The Interview`,
`Last Notable Activity`,`Converted`
from
sampledata;


select * from lead_data;
describe lead_data;

#version control;
create table lead_data_v1 as select * from lead_data ; -- creating a version(table)--

----- Filling Null Values --------

set sql_safe_updates = 0 ;
update lead_data_v1 set `Lead Source` =  'Others'
where lead_data_v1.`Lead Source` = '';

select distinct `Lead Source` from lead_data_v1;

update lead_data_v1 set `what matters most to you in choosing a course` =  'Others'
where lead_data_v1.`what matters most to you in choosing a course` = '';

select `what matters most to you in choosing a course` ,count(`what matters most to you in choosing a course`)
 from lead_data_v1
 group by `what matters most to you in choosing a course`;
 
update lead_data_v1 set `TotalVisits` =  '1'
where lead_data_v1.`TotalVisits` = '';

select COUNT(`TotalVisits`) from lead_data_v1  -- NULL VALUES IN `TotalVisits` COLUMN--
 WHERE `TotalVisits` = '' ;
 
 select `TotalVisits` ,count(`TotalVisits`)
 from lead_data_v1
 group by `TotalVisits`;
 
 update lead_data_v1 set `Total Time Spent on Website` =  '2'
where lead_data_v1.`Total Time Spent on Website` = '';

select `Total Time Spent on Website` ,count(`Total Time Spent on Website`)
 from lead_data_v1
 group by `Total Time Spent on Website`;


select `Page Views Per Visit` ,count(`Page Views Per Visit`)
from lead_data_v1
group by `Page Views Per Visit`;

update lead_data_v1 set `Page Views Per Visit` =  '2'
where lead_data_v1.`Page Views Per Visit` = '';

select `Country` ,count(`Country`)
from lead_data_v1
group by `Country`;

update lead_data_v1 set `Country` =  'Others'
where lead_data_v1.`Country` = '';

select `Specialization` ,count(`Specialization`)
from lead_data_v1
group by `Specialization`;

update lead_data_v1 set `Specialization` =  'Others'
where lead_data_v1.`Specialization` = '';

select `How did you hear about X Education` ,count(`How did you hear about X Education`)
from lead_data_v1
group by `How did you hear about X Education`;

update lead_data_v1 set `How did you hear about X Education` =  'Not_Available'
where lead_data_v1.`How did you hear about X Education` = '';

select `What is your current occupation` ,count(`What is your current occupation`)
from lead_data_v1
group by `What is your current occupation`;

update lead_data_v1 set `What is your current occupation` =  'Not_Available'
where lead_data_v1.`What is your current occupation` = '';

select `Lead Quality` ,count(`Lead Quality`)
from lead_data_v1
group by `Lead Quality`;

update lead_data_v1 set `Lead Quality` =  'Not_Available'
where lead_data_v1.`Lead Quality` = '';

select `Lead Profile` ,count(`Lead Profile`)
from lead_data_v1
group by `Lead Profile`;

update lead_data_v1 set `Lead Profile` =  'Not_Available'
where lead_data_v1.`Lead Profile` = '';

select `City` ,count(`City`)
from lead_data_v1
group by `City`;

update lead_data_v1 set `City` =  'Some_Other_Place'
where lead_data_v1.`City` = '';




